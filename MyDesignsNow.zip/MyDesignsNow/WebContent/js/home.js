function adjustSize() {
	var windowHeight = $(window).height();
	var headerLogoHeight = (windowHeight / 10) + "px";
	$("#headerLogo").css('max-height', headerLogoHeight);
	$(".headerImg").css('height', headerLogoHeight);
	$("#mainDiv").css('height', '80%');
	$("#mainDiv").css('padding-bottom', '0px');
}

function openHomePage() {
	$("#homeLi").addClass('active');
	$("#contactUsLi").removeClass('active');
	$("#categoriesLi").removeClass('active');
	$("#aboutUsLi").removeClass('active');
	$("#mainDiv").load("html/home.html");
	setTimeout(function(){
		homePageContent(1);
	}, 1000);
}

function homePageContent(value) {

	var html = '';
	if(value != null) {
		switch(value) {
		case 1:
		html = '<div class="row">\
					<div class="col-md-4">\
						<div class="thumbnail">\
							<a href="images/home/home_paintings.jpg">\
								<img src="images/home/home_paintings.jpg" alt="Celebrate" style="width:100%; ">\
							</a>\
						</div>\
					</div>\
					<div class="col-md-4">\
						<div class="thumbnail">\
							<a href="images/home/home_fylo.jpg">\
								<img src="images/home/home_fylo.jpg" alt="For Your Loved One\'s" style="width:100%; ">\
							</a>\
						</div>\
					</div>\
					<div class="col-md-4">\
						<div class="thumbnail">\
							<a href="images/home/home_hob.jpg">\
								<img src="images/home/home_hob.jpg" alt="Handicrafts Of Bengal" style="width:100%; ">\
							</a>\
						</div>\
					</div>\
				</div>\
				<div class="row">\
					<div class="col-md-4">\
						<div class="thumbnail">\
							<a href="images/home/home_celebrate.jpg">\
								<img src="images/home/home_celebrate.jpg" alt="Celebrate" style="width:100%; ">\
							</a>\
						</div>\
					</div>\
					<div class="col-md-4">\
						<div class="thumbnail">\
							<a href="images/home/home_photography.jpg">\
								<img src="images/home/home_photography.jpg" alt="Photography" style="width:100%; ">\
							</a>\
						</div>\
					</div>\
					<div class="col-md-4">\
						<div class="thumbnail">\
							<a href="images/home/home_special.jpeg">\
								<img src="images/home/home_special.jpeg" alt="Special" style="width:100%; ">\
							</a>\
						</div>\
					</div>\
				</div>\
				<div class="row">\
					<div class="col-md-4">\
						<div class="thumbnail">\
							<a href="images/home/home_paintings.jpg">\
								<img src="images/home/home_wc.jpg" alt="Wedding Cards" style="width:100%; ">\
							</a>\
						</div>\
					</div>\
				</div>';
		break;
		case 2:
			html = '<div class="row">\
				<div class="col-md-4">\
					<div class="thumbnail">\
						<a href="images/home/home_celebrate.jpg">\
							<img src="images/home/home_celebrate.jpg" alt="Celebrate" style="width:100%; ">\
						</a>\
					</div>\
				</div>\
				</div>';
			break;
		case 3:
			html = '<div class="row">\
				<div class="col-md-4">\
					<div class="thumbnail">\
						<a href="images/home/home_fylo.jpg">\
							<img src="images/home/home_fylo.jpg" alt="For Your Loved One\'s" style="width:100%; ">\
						</a>\
					</div>\
				</div>\
				</div>';
			break;
		case 4:
			html = '<div class="row">\
				<div class="col-md-4">\
					<div class="thumbnail">\
						<a href="images/home/home_hob.jpg">\
							<img src="images/home/home_hob.jpg" alt="Handicrafts Of Bengal" style="width:100%; ">\
						</a>\
					</div>\
				</div>\
				</div>';
			break;
		case 5:
			html = '<div class="row">\
				<div class="col-md-4">\
					<div class="thumbnail">\
						<a href="images/home/home_paintings.jpg">\
							<img src="images/home/home_paintings.jpg" alt="Paintings" style="width:100%; ">\
						</a>\
					</div>\
				</div>\
				</div>';
			break;
		case 6:
			html = '<div class="row">\
				<div class="col-md-4">\
					<div class="thumbnail">\
						<a href="images/home/home_photography.jpg">\
							<img src="images/home/home_photography.jpg" alt="Photography" style="width:100%; ">\
						</a>\
					</div>\
				</div>\
				</div>';
			break;
		case 7:
			html = '<div class="row">\
				<div class="col-md-4">\
					<div class="thumbnail">\
						<a href="images/home/home_special.jpeg">\
							<img src="images/home/home_special.jpeg" alt="Special" style="width:100%; ">\
						</a>\
					</div>\
				</div>\
				</div>';
			break;
		case 8:
			html = '<div class="row">\
				<div class="col-md-4">\
					<div class="thumbnail">\
						<a href="images/home/home_wc.jpg">\
							<img src="images/home/home_wc.jpg" alt="Weddingh Cards" style="width:100%; ">\
						</a>\
					</div>\
				</div>\
				</div>';
			break;
		default:
			break;
		}
	}
	$('#homeTabContent.panel-body').html(html);
}

function homePageContentOld(value) {
	var dir = "images/home/";
	var filename = "home_";
	if (value != null) {
		switch (value) {
		case 1:
			filename = "home_";
			break;
		case 2:
			filename = "home_celebrate_";
			break;
		case 3:
			filename = "home_fylo";
			break;
		case 4:
			filename = "home_hob";
			break;
		case 5:
			filename = "home_paintings";
			break;
		case 6:
			filename = "home_photography";
			break;
		case 7:
			filename = "home_special";
			break;
		case 8:
			filename = "home_wc";
			break;
		default:
			filename = "home_";
			break;
		}
	}
	$.ajax({
		url : dir,
		success : function(data) {
			$(data).find("a:contains(" + fileextension + ")").each(
					function() {
						var filename = this.href.replace(window.location.host,
								"").replace("http://", "");
						$("homeTabContent").append(
								"<img src='" + dir + filename + "'>");
					});
		}
	});
}

function openContactUs() {
	$("#contactUsLi").addClass('active');
	$("#homeLi").removeClass('active');
	$("#categoriesLi").removeClass('active');
	$("#aboutUsLi").removeClass('active');
	$("#mainDiv").load("html/contactus.html");
}

function openCategories(no) {
	$("#categoriesLi").addClass('active');
	$("#homeLi").removeClass('active');
	$("#contactUsLi").removeClass('active');
	$("#aboutUsLi").removeClass('active');
	$("#mainDiv").load("html/categories.html");
}

function openAboutUs() {
	$("#aboutUsLi").addClass('active');
	$("#homeLi").removeClass('active');
	$("#categoriesLi").removeClass('active');
	$("#contactUsLi").removeClass('active');
	$("#mainDiv").load("html/aboutus.html");
}